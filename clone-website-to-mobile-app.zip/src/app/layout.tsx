import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "LuckRiot — Your Luck Starts Here",
  description: "Join LuckRiot and claim your exclusive welcome bonus. Premium gaming experience with slots, roulette, crash games and more.",
  icons: { icon: "/images/logo.png" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#0a0a14",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-dark-900 text-slate-200 antialiased overflow-x-hidden">
        {children}
      </body>
    </html>
  );
}
