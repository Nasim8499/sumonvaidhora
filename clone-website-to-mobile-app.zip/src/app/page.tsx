import { Suspense } from "react";
import MainApp from "@/components/MainApp";

export default function Page() {
  return (
    <Suspense fallback={<LoadingScreen />}>
      <MainApp />
    </Suspense>
  );
}

function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-dark-900 flex items-center justify-center z-50">
      <div className="flex flex-col items-center gap-4">
        <div className="w-16 h-16 rounded-full border-4 border-dark-600 border-t-gold-400 animate-spin" />
        <p className="text-gold-400 font-bold text-lg tracking-wider uppercase">Loading...</p>
      </div>
    </div>
  );
}
