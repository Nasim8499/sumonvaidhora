import { db } from "@/db";
import { promoClicks } from "@/db/schema";
import { headers } from "next/headers";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { promoCode, clickId } = body;
    const hdrs = await headers();
    const ip = hdrs.get("x-forwarded-for") || hdrs.get("x-real-ip") || "unknown";
    const userAgent = hdrs.get("user-agent") || "";
    const referrer = hdrs.get("referer") || "";

    await db.insert(promoClicks).values({
      promoCode: promoCode || "LUCK500",
      clickId: clickId || null,
      ipAddress: ip,
      userAgent,
      referrer,
    });

    return Response.json({ ok: true, message: "Tracked" });
  } catch (err) {
    console.error("Track error:", err);
    return Response.json({ ok: false }, { status: 500 });
  }
}
