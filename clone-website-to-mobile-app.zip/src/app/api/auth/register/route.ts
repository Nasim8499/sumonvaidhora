import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { email, username, password, promoCode } = body;

    if (!email || !username || !password) {
      return Response.json({ ok: false, error: "All fields are required" }, { status: 400 });
    }

    const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (existing.length > 0) {
      return Response.json({ ok: false, error: "Email already registered" }, { status: 409 });
    }

    const bonusAmount = promoCode === "LUCK500" ? 500 : 0;

    const [newUser] = await db.insert(users).values({
      email,
      username,
      passwordHash: password, // In production, use bcrypt
      promoCode: promoCode || null,
      balance: bonusAmount,
    }).returning();

    return Response.json({
      ok: true,
      user: {
        id: newUser.id,
        username: newUser.username,
        email: newUser.email,
        balance: newUser.balance,
        promoCode: newUser.promoCode,
      },
    });
  } catch (err) {
    console.error("Register error:", err);
    return Response.json({ ok: false, error: "Server error" }, { status: 500 });
  }
}
