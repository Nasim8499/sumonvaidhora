import { pgTable, serial, text, timestamp, varchar, integer } from "drizzle-orm/pg-core";

export const promoClicks = pgTable("promo_clicks", {
  id: serial("id").primaryKey(),
  promoCode: varchar("promo_code", { length: 50 }).notNull(),
  clickId: varchar("click_id", { length: 100 }),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  referrer: text("referrer"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  username: varchar("username", { length: 50 }).notNull(),
  passwordHash: text("password_hash").notNull(),
  promoCode: varchar("promo_code", { length: 50 }),
  balance: integer("balance").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
