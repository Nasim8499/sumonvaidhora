"use client";

import { useState, useEffect } from "react";

interface HeaderProps {
  onLogin: () => void;
  onRegister: () => void;
}

export default function Header({ onLogin, onRegister }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 safe-top ${
        scrolled ? "glass-dark shadow-xl shadow-black/30" : "bg-transparent"
      }`}
    >
      <div className="max-w-lg mx-auto flex items-center justify-between px-4 py-3">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <img
            src="/images/logo.png"
            alt="LuckRiot"
            className="w-9 h-9 rounded-lg"
          />
          <div className="flex flex-col">
            <span className="text-lg font-black tracking-tight text-gold-gradient leading-none">
              LUCKRIOT
            </span>
            <span className="text-[9px] text-slate-500 tracking-[3px] uppercase leading-none mt-0.5">
              Premium Gaming
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={onLogin}
            className="text-sm font-semibold text-slate-300 hover:text-white transition-colors px-3 py-2"
          >
            Sign In
          </button>
          <button
            onClick={onRegister}
            className="text-sm font-bold gold-gradient text-dark-900 px-4 py-2 rounded-xl transition-all active:scale-95"
          >
            Join
          </button>
        </div>
      </div>
    </header>
  );
}
