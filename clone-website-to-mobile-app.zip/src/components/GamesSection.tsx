"use client";

import { useState } from "react";

interface GamesProps {
  fullPage?: boolean;
}

const CATEGORIES = ["All", "Slots", "Table", "Crash", "Live", "New"];

const GAMES = [
  { name: "Lucky Spins Deluxe", category: "Slots", image: "/images/game-slots.jpg", players: 1243, tag: "HOT" },
  { name: "Royal Roulette", category: "Table", image: "/images/game-roulette.jpg", players: 876, tag: "POPULAR" },
  { name: "Blackjack Pro", category: "Table", image: "/images/game-cards.jpg", players: 654, tag: "CLASSIC" },
  { name: "Crash X Turbo", category: "Crash", image: "/images/game-crash.jpg", players: 2100, tag: "TRENDING" },
  { name: "Dragon Fortune", category: "Slots", image: "/images/game-slots.jpg", players: 988, tag: "NEW" },
  { name: "Mega Dice", category: "Crash", image: "/images/game-roulette.jpg", players: 541, tag: "LIVE" },
  { name: "Gold Mine Slots", category: "Slots", image: "/images/game-cards.jpg", players: 1567, tag: "TOP" },
  { name: "Speed Baccarat", category: "Live", image: "/images/game-roulette.jpg", players: 433, tag: "LIVE" },
  { name: "Neon Reels", category: "New", image: "/images/game-crash.jpg", players: 312, tag: "NEW" },
  { name: "Pirate Treasures", category: "Slots", image: "/images/game-slots.jpg", players: 789, tag: "HOT" },
  { name: "Lightning Poker", category: "Table", image: "/images/game-cards.jpg", players: 921, tag: "VIP" },
  { name: "Moon Rocket", category: "Crash", image: "/images/game-crash.jpg", players: 1876, tag: "TRENDING" },
];

export default function GamesSection({ fullPage }: GamesProps) {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredGames = activeCategory === "All"
    ? GAMES
    : GAMES.filter(g => g.category === activeCategory);

  return (
    <section className={`px-4 ${fullPage ? "pt-24 pb-32" : "py-10"}`}>
      <div className="max-w-lg mx-auto">
        {/* Section Header */}
        <div className="flex items-end justify-between mb-5">
          <div>
            <p className="text-xs text-neon-purple font-bold tracking-[4px] uppercase mb-1">
              Games
            </p>
            <h2 className="text-2xl font-black text-white">
              Popular <span className="text-gold-gradient">Games</span>
            </h2>
          </div>
          <button className="text-xs text-neon-purple font-semibold hover:underline">
            View All →
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-3 mb-4 no-scrollbar">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                activeCategory === cat
                  ? "gold-gradient text-dark-900"
                  : "glass text-slate-400 hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {filteredGames.map((game) => (
            <button
              key={game.name}
              className="group relative rounded-xl overflow-hidden aspect-[3/4] active:scale-[0.97] transition-transform"
            >
              <img
                src={game.image}
                alt={game.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-dark-900/30 to-transparent" />
              
              {/* Tag */}
              <div className="absolute top-2 left-2">
                <span className="text-[9px] font-bold bg-neon-purple/90 text-white px-2 py-0.5 rounded-full">
                  {game.tag}
                </span>
              </div>

              {/* Game Info */}
              <div className="absolute bottom-0 left-0 right-0 p-3">
                <h3 className="text-xs font-bold text-white leading-tight truncate">{game.name}</h3>
                <div className="flex items-center gap-1 mt-1">
                  <span className="relative flex h-1.5 w-1.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-neon-green opacity-75" />
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-neon-green" />
                  </span>
                  <span className="text-[10px] text-slate-400">{game.players.toLocaleString()} playing</span>
                </div>
              </div>

              {/* Play Overlay */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-dark-900/40">
                <div className="w-12 h-12 rounded-full gold-gradient flex items-center justify-center">
                  <svg className="w-5 h-5 text-dark-900 ml-0.5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
