"use client";

import { useState, useEffect } from "react";

interface HeroProps {
  promoCode: string;
  onClaim: () => void;
}

export default function HeroSection({ promoCode, onClaim }: HeroProps) {
  const [count, setCount] = useState(0);
  const target = 500;

  useEffect(() => {
    let frame: number;
    const start = performance.now();
    const duration = 2000;
    const step = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * target));
      if (progress < 1) frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, []);

  return (
    <section className="relative pt-20 pb-4 overflow-hidden">
      {/* Hero Background */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/hero-bg.jpg"
          alt=""
          className="w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-dark-900/40 via-dark-900/70 to-dark-900" />
      </div>

      <div className="relative z-10 max-w-lg mx-auto px-4 pt-10 pb-6">
        {/* Promo Badge */}
        <div className="flex justify-center mb-6">
          <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-2 animate-slide-up">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-neon-green opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-neon-green" />
            </span>
            <span className="text-xs font-semibold text-neon-green">EXCLUSIVE OFFER ACTIVE</span>
          </div>
        </div>

        {/* Main Headline */}
        <div className="text-center space-y-4 animate-slide-up" style={{ animationDelay: "0.1s" }}>
          <h1 className="text-4xl sm:text-5xl font-black leading-[1.1]">
            <span className="text-white">Your Luck</span>
            <br />
            <span className="text-gold-gradient">Starts Here</span>
          </h1>
          
          <p className="text-slate-400 text-base max-w-xs mx-auto">
            Claim your exclusive welcome bonus and start winning with premium games
          </p>
        </div>

        {/* Bonus Counter */}
        <div className="mt-8 animate-slide-up" style={{ animationDelay: "0.2s" }}>
          <div className="neon-border rounded-2xl p-6 text-center relative overflow-hidden">
            <div className="absolute inset-0 animate-shimmer" />
            <p className="text-xs text-slate-400 uppercase tracking-widest mb-2">Welcome Bonus</p>
            <div className="flex items-center justify-center gap-1">
              <span className="text-5xl sm:text-6xl font-black text-gold-gradient">{count}%</span>
            </div>
            <p className="text-sm text-slate-400 mt-2">on your first deposit</p>
            
            {/* Promo Code Display */}
            <div className="mt-4 flex items-center justify-center gap-2">
              <div className="bg-dark-900/80 border border-gold-400/30 rounded-lg px-4 py-2 flex items-center gap-2">
                <svg className="w-4 h-4 text-gold-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
                </svg>
                <span className="text-gold-400 font-mono font-bold tracking-wider text-sm">{promoCode}</span>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="mt-6 space-y-3 animate-slide-up" style={{ animationDelay: "0.3s" }}>
          <button
            onClick={onClaim}
            className="btn-primary w-full text-center animate-gold-pulse relative"
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              🎰 Claim {promoCode} Bonus
            </span>
          </button>
          <p className="text-center text-[11px] text-slate-500">
            ✓ No hidden fees · ✓ Instant activation · ✓ 18+ T&Cs apply
          </p>
        </div>

        {/* Stats Row */}
        <div className="mt-8 grid grid-cols-3 gap-3 animate-slide-up" style={{ animationDelay: "0.4s" }}>
          {[
            { value: "50K+", label: "Players" },
            { value: "$2M+", label: "Paid Out" },
            { value: "500+", label: "Games" },
          ].map((stat) => (
            <div key={stat.label} className="glass rounded-xl p-3 text-center">
              <p className="text-lg font-black text-white">{stat.value}</p>
              <p className="text-[10px] text-slate-400 uppercase tracking-wider">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
