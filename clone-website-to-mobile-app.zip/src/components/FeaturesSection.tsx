"use client";

const FEATURES = [
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z" />
      </svg>
    ),
    title: "Provably Fair",
    desc: "Every game outcome is verifiable and transparent using blockchain technology",
    color: "text-neon-green",
    bg: "bg-neon-green/10",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
      </svg>
    ),
    title: "Instant Payouts",
    desc: "Withdraw your winnings instantly with crypto or traditional payment methods",
    color: "text-gold-400",
    bg: "bg-gold-400/10",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 9.563C9 9.252 9.252 9 9.563 9h4.874c.311 0 .563.252.563.563v4.874c0 .311-.252.563-.563.563H9.564A.562.562 0 0 1 9 14.437V9.564Z" />
      </svg>
    ),
    title: "24/7 Support",
    desc: "Our dedicated support team is available around the clock to assist you",
    color: "text-neon-blue",
    bg: "bg-neon-blue/10",
  },
  {
    icon: (
      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 0 0 6 3.75v16.5a2.25 2.25 0 0 0 2.25 2.25h7.5A2.25 2.25 0 0 0 18 20.25V3.75a2.25 2.25 0 0 0-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18.75h3" />
      </svg>
    ),
    title: "Mobile First",
    desc: "Play anywhere, anytime with our optimized mobile gaming experience",
    color: "text-neon-pink",
    bg: "bg-neon-pink/10",
  },
];

const REVIEWS = [
  { name: "Alex M.", rating: 5, text: "Best bonus I've ever received. Instant withdrawals too!", avatar: "🧑‍💻" },
  { name: "Sarah K.", rating: 5, text: "Love the game variety. The crash games are amazing!", avatar: "👩‍🎤" },
  { name: "Mike R.", rating: 5, text: "VIP support is top notch. Highly recommend!", avatar: "🧔" },
];

export default function FeaturesSection() {
  return (
    <section className="px-4 py-10">
      <div className="max-w-lg mx-auto space-y-12">
        {/* Why Choose Us */}
        <div>
          <div className="text-center mb-8">
            <p className="text-xs text-neon-purple font-bold tracking-[4px] uppercase mb-2">
              Why Us
            </p>
            <h2 className="text-2xl font-black text-white">
              Why Choose <span className="text-gold-gradient">LuckRiot</span>
            </h2>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {FEATURES.map((f) => (
              <div key={f.title} className="glass rounded-xl p-4 space-y-3">
                <div className={`w-10 h-10 rounded-xl ${f.bg} flex items-center justify-center ${f.color}`}>
                  {f.icon}
                </div>
                <h3 className="text-sm font-bold text-white">{f.title}</h3>
                <p className="text-[11px] text-slate-400 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Payment Methods */}
        <div>
          <div className="text-center mb-6">
            <h3 className="text-lg font-bold text-white">Accepted Payments</h3>
          </div>
          <div className="flex justify-center gap-4 flex-wrap">
            {["💳 Visa", "💳 Mastercard", "🅱️ Bitcoin", "⟠ Ethereum", "💲 USDT", "🏦 Bank"].map(method => (
              <div key={method} className="glass rounded-lg px-3 py-2 text-xs text-slate-400 font-medium">
                {method}
              </div>
            ))}
          </div>
        </div>

        {/* Reviews */}
        <div>
          <div className="text-center mb-6">
            <p className="text-xs text-neon-purple font-bold tracking-[4px] uppercase mb-2">
              Reviews
            </p>
            <h2 className="text-2xl font-black text-white">
              Player <span className="text-gold-gradient">Reviews</span>
            </h2>
          </div>

          <div className="space-y-3">
            {REVIEWS.map((review) => (
              <div key={review.name} className="glass rounded-xl p-4">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-2xl">{review.avatar}</span>
                  <div>
                    <p className="text-sm font-bold text-white">{review.name}</p>
                    <div className="flex gap-0.5">
                      {Array.from({ length: review.rating }, (_, i) => (
                        <span key={i} className="text-gold-400 text-xs">★</span>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{review.text}</p>
              </div>
            ))}
          </div>

          {/* Trust Score */}
          <div className="mt-6 glass rounded-xl p-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-1">
              <span className="text-gold-400 text-sm">★★★★★</span>
              <span className="text-lg font-black text-white">4.9</span>
            </div>
            <p className="text-xs text-slate-400">Based on 12,453 player reviews</p>
          </div>
        </div>
      </div>
    </section>
  );
}
