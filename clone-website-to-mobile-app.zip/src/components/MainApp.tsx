"use client";

import { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "next/navigation";
import Header from "./Header";
import HeroSection from "./HeroSection";
import PromoSection from "./PromoSection";
import GamesSection from "./GamesSection";
import FeaturesSection from "./FeaturesSection";
import LiveFeed from "./LiveFeed";
import AuthModal from "./AuthModal";
import BottomNav from "./BottomNav";

export default function MainApp() {
  const searchParams = useSearchParams();
  const promo = searchParams.get("promo") || "LUCK500";
  const visiblePromo = searchParams.get("visiblePromo") || promo;
  const clickId = searchParams.get("click") || "";

  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("register");
  const [activeTab, setActiveTab] = useState("home");

  useEffect(() => {
    if (clickId) {
      fetch("/api/promo/track", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ promoCode: promo, clickId }),
      }).catch(() => {});
    }
  }, [clickId, promo]);

  const openRegister = useCallback(() => {
    setAuthMode("register");
    setShowAuth(true);
  }, []);

  const openLogin = useCallback(() => {
    setAuthMode("login");
    setShowAuth(true);
  }, []);

  return (
    <div className="min-h-screen bg-dark-900 relative">
      {/* Background ambient effects */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-neon-purple/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-0 w-[400px] h-[400px] bg-neon-blue/5 rounded-full blur-[100px]" />
        <div className="absolute top-1/2 left-0 w-[300px] h-[300px] bg-neon-pink/3 rounded-full blur-[80px]" />
      </div>

      <div className="relative z-10">
        <Header onLogin={openLogin} onRegister={openRegister} />
        
        {activeTab === "home" && (
          <>
            <HeroSection promoCode={visiblePromo} onClaim={openRegister} />
            <LiveFeed />
            <PromoSection promoCode={visiblePromo} onClaim={openRegister} />
            <GamesSection />
            <FeaturesSection />
            <FooterSection onRegister={openRegister} />
          </>
        )}

        {activeTab === "games" && <GamesSection fullPage />}
        {activeTab === "promo" && <PromoSection promoCode={visiblePromo} onClaim={openRegister} fullPage />}
        {activeTab === "profile" && <ProfilePlaceholder onLogin={openLogin} />}
      </div>

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      {showAuth && (
        <AuthModal
          mode={authMode}
          promoCode={promo}
          onClose={() => setShowAuth(false)}
          onToggleMode={() => setAuthMode(m => m === "login" ? "register" : "login")}
        />
      )}
    </div>
  );
}

function FooterSection({ onRegister }: { onRegister: () => void }) {
  return (
    <footer className="px-4 pt-12 pb-32 border-t border-white/5">
      <div className="max-w-lg mx-auto text-center space-y-6">
        <div className="flex items-center justify-center gap-2">
          <img src="/images/logo.png" alt="LuckRiot" className="w-10 h-10 rounded-lg" />
          <span className="text-2xl font-black text-gold-gradient">LUCKRIOT</span>
        </div>
        <p className="text-sm text-slate-400 max-w-xs mx-auto">
          Premium gaming platform with exclusive bonuses and a world-class experience.
        </p>
        <button onClick={onRegister} className="btn-primary w-full max-w-xs mx-auto block">
          Join Now & Claim Bonus
        </button>
        <div className="flex justify-center gap-6 pt-4">
          {["Terms", "Privacy", "Support", "FAQ"].map(item => (
            <button key={item} className="text-xs text-slate-500 hover:text-slate-300 transition-colors">
              {item}
            </button>
          ))}
        </div>
        <div className="flex justify-center gap-3 pt-2">
          <span className="text-[10px] px-2 py-1 rounded bg-dark-600 text-slate-400">18+</span>
          <span className="text-[10px] px-2 py-1 rounded bg-dark-600 text-slate-400">Play Responsibly</span>
          <span className="text-[10px] px-2 py-1 rounded bg-dark-600 text-slate-400">Licensed</span>
        </div>
        <p className="text-[10px] text-slate-600 pt-4">© 2026 LuckRiot. All rights reserved.</p>
      </div>
    </footer>
  );
}

function ProfilePlaceholder({ onLogin }: { onLogin: () => void }) {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 pb-24">
      <div className="glass rounded-2xl p-8 max-w-sm w-full text-center space-y-6">
        <div className="w-20 h-20 rounded-full bg-dark-600 mx-auto flex items-center justify-center">
          <svg className="w-10 h-10 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
          </svg>
        </div>
        <h3 className="text-xl font-bold">Sign In Required</h3>
        <p className="text-sm text-slate-400">Log in or create an account to access your profile and track your rewards.</p>
        <button onClick={onLogin} className="btn-primary w-full">Sign In</button>
      </div>
    </div>
  );
}
