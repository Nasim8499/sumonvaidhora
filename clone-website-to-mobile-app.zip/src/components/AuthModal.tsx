"use client";

import { useState } from "react";

interface AuthModalProps {
  mode: "login" | "register";
  promoCode: string;
  onClose: () => void;
  onToggleMode: () => void;
}

export default function AuthModal({ mode, promoCode, onClose, onToggleMode }: AuthModalProps) {
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      if (mode === "register") {
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, username, password, promoCode }),
        });
        const data = await res.json();
        if (!data.ok) {
          setError(data.error || "Registration failed");
        } else {
          setSuccess(true);
        }
      } else {
        // Login placeholder
        setSuccess(true);
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-md bg-dark-800 rounded-t-3xl sm:rounded-3xl border-t border-white/10 sm:border sm:border-white/10 animate-slide-up max-h-[90vh] overflow-y-auto safe-bottom">
        {/* Handle bar (mobile) */}
        <div className="flex justify-center pt-3 sm:hidden">
          <div className="w-10 h-1 rounded-full bg-white/20" />
        </div>

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-slate-400 hover:text-white transition-colors z-10"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="p-6 pt-5 sm:pt-6">
          {success ? (
            <SuccessState mode={mode} promoCode={promoCode} onClose={onClose} />
          ) : (
            <>
              {/* Header */}
              <div className="text-center mb-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-2xl gold-gradient flex items-center justify-center">
                  <span className="text-3xl">
                    {mode === "register" ? "🎰" : "👋"}
                  </span>
                </div>
                <h2 className="text-2xl font-black text-white">
                  {mode === "register" ? "Create Account" : "Welcome Back"}
                </h2>
                <p className="text-sm text-slate-400 mt-1">
                  {mode === "register"
                    ? "Sign up & activate your bonus"
                    : "Sign in to your account"}
                </p>
              </div>

              {/* Promo Banner (Register only) */}
              {mode === "register" && (
                <div className="mb-5 neon-border rounded-xl p-3 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gold-400/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-lg">🎁</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-gold-400">BONUS ACTIVATED</p>
                    <p className="text-[11px] text-slate-400">
                      Code <span className="text-gold-400 font-mono font-bold">{promoCode}</span> — 500% Welcome Bonus
                    </p>
                  </div>
                  <svg className="w-5 h-5 text-neon-green flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                  </svg>
                </div>
              )}

              {/* Error */}
              {error && (
                <div className="mb-4 bg-red-500/10 border border-red-500/20 rounded-xl p-3 flex items-center gap-2">
                  <svg className="w-4 h-4 text-red-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z" />
                  </svg>
                  <p className="text-xs text-red-400">{error}</p>
                </div>
              )}

              {/* Form */}
              <form onSubmit={handleSubmit} className="space-y-3">
                {mode === "register" && (
                  <div>
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                      Username
                    </label>
                    <input
                      type="text"
                      value={username}
                      onChange={e => setUsername(e.target.value)}
                      placeholder="Choose a username"
                      required
                      className="w-full bg-dark-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-neon-purple/50 focus:ring-1 focus:ring-neon-purple/20 transition-all"
                    />
                  </div>
                )}

                <div>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Email
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    required
                    className="w-full bg-dark-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-neon-purple/50 focus:ring-1 focus:ring-neon-purple/20 transition-all"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Password
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Create a strong password"
                    required
                    minLength={6}
                    className="w-full bg-dark-900 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-neon-purple/50 focus:ring-1 focus:ring-neon-purple/20 transition-all"
                  />
                </div>

                {mode === "register" && (
                  <div className="flex items-start gap-2 pt-1">
                    <input type="checkbox" required className="mt-1 accent-neon-purple" />
                    <p className="text-[11px] text-slate-500">
                      I am 18+ and agree to the Terms of Service and Privacy Policy
                    </p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="btn-primary w-full mt-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-dark-900/30 border-t-dark-900 rounded-full animate-spin" />
                  ) : mode === "register" ? (
                    <>🎰 Create Account & Get Bonus</>
                  ) : (
                    <>Sign In</>
                  )}
                </button>
              </form>

              {/* Divider */}
              <div className="flex items-center gap-3 my-5">
                <div className="flex-1 h-px bg-white/5" />
                <span className="text-[10px] text-slate-500 uppercase tracking-wider">or</span>
                <div className="flex-1 h-px bg-white/5" />
              </div>

              {/* Social Buttons */}
              <div className="grid grid-cols-2 gap-2">
                <button className="glass rounded-xl py-2.5 text-sm font-medium text-slate-300 flex items-center justify-center gap-2 active:scale-95 transition-transform">
                  <span>🔵</span> Google
                </button>
                <button className="glass rounded-xl py-2.5 text-sm font-medium text-slate-300 flex items-center justify-center gap-2 active:scale-95 transition-transform">
                  <span>📱</span> Telegram
                </button>
              </div>

              {/* Toggle Mode */}
              <p className="text-center text-xs text-slate-500 mt-5">
                {mode === "register" ? "Already have an account?" : "Don't have an account?"}{" "}
                <button
                  onClick={onToggleMode}
                  className="text-neon-purple font-semibold hover:underline"
                >
                  {mode === "register" ? "Sign In" : "Create Account"}
                </button>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function SuccessState({ mode, promoCode, onClose }: { mode: string; promoCode: string; onClose: () => void }) {
  return (
    <div className="text-center py-6 space-y-5">
      <div className="w-20 h-20 mx-auto rounded-full bg-neon-green/10 flex items-center justify-center">
        <svg className="w-10 h-10 text-neon-green" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
        </svg>
      </div>
      <div>
        <h3 className="text-2xl font-black text-white">
          {mode === "register" ? "Account Created!" : "Welcome Back!"}
        </h3>
        <p className="text-sm text-slate-400 mt-2">
          {mode === "register"
            ? `Your bonus code ${promoCode} has been activated. Make your first deposit to claim 500%!`
            : "You have been signed in successfully."}
        </p>
      </div>

      {mode === "register" && (
        <div className="neon-border rounded-xl p-4">
          <p className="text-xs text-slate-400 mb-1">Your Bonus Balance</p>
          <p className="text-3xl font-black text-gold-gradient">$500.00</p>
          <p className="text-xs text-slate-400 mt-1">Available after first deposit</p>
        </div>
      )}

      <button onClick={onClose} className="btn-primary w-full">
        {mode === "register" ? "🎰 Start Playing" : "Continue"}
      </button>
    </div>
  );
}
