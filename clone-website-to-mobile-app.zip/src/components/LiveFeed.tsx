"use client";

import { useState, useEffect } from "react";

const NAMES = [
  "Alex", "Maria", "James", "Sofia", "Mike", "Emma", "David", "Luna",
  "Jake", "Aria", "Leo", "Mia", "Max", "Zara", "Noah", "Ivy",
  "Ryan", "Chloe", "Ethan", "Lila", "Oscar", "Nina", "Felix", "Ruby",
];

const GAMES = [
  { name: "Lucky Spins", emoji: "🎰" },
  { name: "Royal Roulette", emoji: "🎡" },
  { name: "Crash X", emoji: "🚀" },
  { name: "Blackjack Pro", emoji: "🃏" },
  { name: "Dragon Slots", emoji: "🐉" },
  { name: "Gold Rush", emoji: "💰" },
  { name: "Dice Royale", emoji: "🎲" },
  { name: "Mega Fortune", emoji: "💎" },
];

function generateWin() {
  const name = NAMES[Math.floor(Math.random() * NAMES.length)];
  const game = GAMES[Math.floor(Math.random() * GAMES.length)];
  const amount = (Math.random() * 5000 + 10).toFixed(2);
  const hiddenName = name[0] + "***" + name[name.length - 1];
  return { name: hiddenName, game, amount, id: Math.random().toString(36).slice(2) };
}

export default function LiveFeed() {
  const [wins, setWins] = useState(() =>
    Array.from({ length: 12 }, generateWin)
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setWins(prev => [generateWin(), ...prev.slice(0, 11)]);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-4 overflow-hidden">
      <div className="relative">
        {/* Fade edges */}
        <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-dark-900 to-transparent z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-dark-900 to-transparent z-10" />
        
        <div className="flex gap-3 animate-marquee whitespace-nowrap">
          {[...wins, ...wins].map((win, i) => (
            <div
              key={`${win.id}-${i}`}
              className="inline-flex items-center gap-2 glass rounded-full px-3 py-1.5 flex-shrink-0"
            >
              <span className="text-sm">{win.game.emoji}</span>
              <span className="text-xs text-slate-400">{win.name}</span>
              <span className="text-xs font-bold text-neon-green">+${win.amount}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
