"use client";

interface PromoProps {
  promoCode: string;
  onClaim: () => void;
  fullPage?: boolean;
}

const BONUSES = [
  {
    title: "Welcome Bonus",
    desc: "500% on your first deposit",
    icon: "🎁",
    color: "from-yellow-500/20 to-amber-600/20",
    border: "border-yellow-500/20",
    tag: "MOST POPULAR",
  },
  {
    title: "Free Spins",
    desc: "200 free spins on top slots",
    icon: "🎰",
    color: "from-purple-500/20 to-pink-500/20",
    border: "border-purple-500/20",
    tag: "NEW",
  },
  {
    title: "Cashback",
    desc: "Up to 25% weekly cashback",
    icon: "💸",
    color: "from-green-500/20 to-emerald-500/20",
    border: "border-green-500/20",
    tag: "VIP",
  },
  {
    title: "Reload Bonus",
    desc: "100% every weekend",
    icon: "🔄",
    color: "from-blue-500/20 to-cyan-500/20",
    border: "border-blue-500/20",
    tag: "WEEKLY",
  },
];

export default function PromoSection({ promoCode, onClaim, fullPage }: PromoProps) {
  return (
    <section className={`px-4 ${fullPage ? "pt-24 pb-32" : "py-10"}`}>
      <div className="max-w-lg mx-auto">
        {/* Section Header */}
        <div className="text-center mb-8">
          <p className="text-xs text-neon-purple font-bold tracking-[4px] uppercase mb-2">
            Promotions
          </p>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Exclusive <span className="text-gold-gradient">Bonuses</span>
          </h2>
          <p className="text-sm text-slate-400 mt-2">
            Use code <span className="text-gold-400 font-bold">{promoCode}</span> to unlock all rewards
          </p>
        </div>

        {/* Promo Banner */}
        <div className="relative rounded-2xl overflow-hidden mb-6">
          <img
            src="/images/promo-banner.jpg"
            alt="Promo"
            className="w-full h-44 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark-900 via-dark-900/60 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-5">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-xs text-gold-400 font-bold uppercase tracking-wider">Limited Time</p>
                <p className="text-2xl font-black text-white mt-1">500% Bonus</p>
                <p className="text-xs text-slate-300 mt-1">First deposit • Code: {promoCode}</p>
              </div>
              <button
                onClick={onClaim}
                className="gold-gradient text-dark-900 font-bold text-sm px-5 py-2.5 rounded-xl active:scale-95 transition-transform"
              >
                Claim
              </button>
            </div>
          </div>
        </div>

        {/* Bonus Cards */}
        <div className="space-y-3">
          {BONUSES.map((bonus) => (
            <button
              key={bonus.title}
              onClick={onClaim}
              className={`w-full glass rounded-xl p-4 flex items-center gap-4 border ${bonus.border} active:scale-[0.98] transition-transform text-left`}
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${bonus.color} flex items-center justify-center text-2xl flex-shrink-0`}>
                {bonus.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white">{bonus.title}</h3>
                  <span className="text-[9px] font-bold bg-neon-purple/20 text-neon-purple px-2 py-0.5 rounded-full">
                    {bonus.tag}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{bonus.desc}</p>
              </div>
              <svg className="w-5 h-5 text-slate-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
              </svg>
            </button>
          ))}
        </div>

        {/* Timer */}
        <div className="mt-6 glass rounded-xl p-4 text-center">
          <p className="text-xs text-slate-400 mb-2">Offer expires in</p>
          <CountdownTimer />
          <button onClick={onClaim} className="btn-primary w-full mt-4 text-sm">
            Activate {promoCode} Now
          </button>
        </div>
      </div>
    </section>
  );
}

function CountdownTimer() {
  return (
    <div className="flex items-center justify-center gap-2">
      {[
        { value: "02", label: "Days" },
        { value: "14", label: "Hours" },
        { value: "37", label: "Mins" },
        { value: "52", label: "Secs" },
      ].map((item, i) => (
        <div key={item.label} className="flex items-center gap-2">
          <div className="bg-dark-900 rounded-lg px-3 py-2 min-w-[44px]">
            <p className="text-xl font-black text-gold-400 font-mono">{item.value}</p>
            <p className="text-[8px] text-slate-500 uppercase tracking-wider">{item.label}</p>
          </div>
          {i < 3 && <span className="text-slate-600 font-bold text-lg">:</span>}
        </div>
      ))}
    </div>
  );
}
